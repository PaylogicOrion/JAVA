package com.example.paylogic.Algo;
import javax.crypto.Cipher;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;

public class Aes{


public static String encrypt(String key, String initVector, String value)
  {
    try
    {
    
      IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
      SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
      
      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
      cipher.init(1, skeySpec, iv);
      
      byte[] encrypted = cipher.doFinal(value.getBytes());
      
      
      return java.util.Base64.getEncoder().encodeToString(encrypted);

    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    
    return null;
  }
  
  public static String decrypt(String key, String initVector, String encrypted)
  {
    try
    {
   
      IvParameterSpec iv = new IvParameterSpec(initVector.getBytes("UTF-8"));
      SecretKeySpec skeySpec = new SecretKeySpec(key.getBytes("UTF-8"), "AES");
      
      Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING");
      cipher.init(2, skeySpec, iv);
      
      byte[] original = cipher.doFinal(java.util.Base64.getDecoder().decode(encrypted));
      return new String(original);

    }
    catch (Exception ex)
    {
      ex.printStackTrace();
    }
    
    return null;
  }
  
}