package com.example.paylogic;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.json.JSONException;
import org.json.JSONObject;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.paylogic.Algo.*;;

@Controller
public class Paylogic {

	Aes a = new Aes();
	
	@GetMapping("/")
	public String get() {
		
		return "index";
	}
	
	@RequestMapping("/sendData")
	public String post(HttpServletRequest r,Model m) throws JSONException
	{
		
		
		JSONObject s = new JSONObject();
		s.put("dateTime", r.getParameter("dateTime"));
		s.put("amount", r.getParameter("amount"));
		s.put("isMultiSettlement", r.getParameter("isMultiSettlement"));
		s.put("custMobile", r.getParameter("custMobile"));
		s.put("apiKey", r.getParameter("apiKey"));
		s.put("productId", r.getParameter("productId"));
		s.put("instrumentId",r.getParameter("instrumentId"));
		s.put("udf5", r.getParameter("udf5"));
		s.put("cardType", r.getParameter("cardType"));
		s.put("txnType", r.getParameter("txnType"));
		s.put("udf3", r.getParameter("udf3"));
		s.put("udf4", r.getParameter("udf4"));
		s.put("udf1", r.getParameter("udf1"));
		s.put("type", r.getParameter("type"));
		s.put("udf2", r.getParameter("udf2"));
		s.put("merchantId", r.getParameter("merchantId"));
		s.put("cardDetails", r.getParameter("cardDetails"));
		s.put("custMail", r.getParameter("custMail"));
		s.put("returnURL", r.getParameter("returnURL"));
		s.put("channelId", r.getParameter("channelId"));
		s.put("txnId", r.getParameter("txnId"));
		
		String iv = r.getParameter("apiKey").substring(0,16);
		
		
		
		String encData = a.encrypt(r.getParameter("apiKey"), iv, s.toString());
	
		m.addAttribute("reqData",encData);
		m.addAttribute("merchantId",r.getParameter("merchantId"));
		m.addAttribute("url",r.getParameter("integrationtype"));
		
		
		return "send";
	}
	
	
	@PostMapping("/response")
	public String response(@RequestParam("respData") String resdata , Model m) throws JSONException {
		
		
		String key ="";  //enter you encryption key here
		
		
		String iv = key.substring(0,16);
		
		
		String decrypted = a.decrypt(key, iv, resdata);
		
		
		JSONObject s = new JSONObject(decrypted);
		
		String msg = s.getString("resp_message");
		
		m.addAttribute("resp_message",s.getString("resp_message"));
		m.addAttribute("txn_id",s.getString("txn_id"));
		m.addAttribute("merchant_id",s.getString("merchant_id"));
		m.addAttribute("pg_ref_id",s.getString("pg_ref_id"));
		m.addAttribute("trans_status",s.getString("trans_status"));
		m.addAttribute("resp_date_time",s.getString("resp_date_time"));
		
		
		return "response";
	}
	
	
}
